def Display():
    print("Inside Display function")
    print(__name__)