import Infosystems

print("Inside User.py file")
print(__name__)

Infosystems.Display()