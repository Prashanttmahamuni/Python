# range(start, end, displacement)

# start is by default 0 if not mentioned
# displacement is by default 1 if not mentioned
# end should be mentioned explicitelly (It gets excluded)

print(list(range(5)))

print(list(range(3,8)))

print(list(range(3,12,2)))

print(list(range(20,1,-1)))
