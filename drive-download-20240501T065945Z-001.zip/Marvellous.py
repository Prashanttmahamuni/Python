def Addition(No1, No2):
    Ans = No1 + No2
    return Ans

def Substraction(No1, No2):
    Ans = No1 - No2
    return Ans

def Multiplication(No1, No2):
    Ans = No1 * No2
    return Ans

def Division(No1, No2):
    Ans = No1 / No2
    return Ans    