Arr = [11, 78.90, True, "Marvellous",11]

print("-----------------------------------")

for value in Arr:
    print(value)

print("-----------------------------------")

for i in range(len(Arr)):
    print(Arr[i])

print("-----------------------------------")
