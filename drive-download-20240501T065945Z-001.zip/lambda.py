def Additoion(A,B):
    Ans = 0
    Ans = A + B
    return Ans

def main():
    Ret = Additoion(10,11)
    print("Addition is : ",Ret)

if __name__ == "__main__":
    main()