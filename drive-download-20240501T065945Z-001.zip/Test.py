
print("Demo python Program.")

No = 11

print(No)
print(type(No))
print(id(No))

X = 21
print(id(X))

Y = 11
print(id(Y))

Z = "11"
print(type(Z))
print(id(Z))

A = 11
B = 11.90
C = "Hello"
D = True
E = 8+7j
