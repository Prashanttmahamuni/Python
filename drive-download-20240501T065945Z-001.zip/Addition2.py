No1 = int(input("Enter first number : "))
No2 = int(input("Enter second number : "))

Ans = No1 + No2

print("Addition is : ",Ans)
