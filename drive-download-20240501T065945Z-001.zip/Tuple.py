# Tuple datatype

# Heterogeneous
# Ordered
# Indexed
# Immutable
# Allows Duplicate

Arr = (11,18.90,True,"Marvellous",11)

print(type(Arr))
print(len(Arr))
print(Arr[0])
print(Arr[2])

Arr[0] = 21
print(Arr[0])
