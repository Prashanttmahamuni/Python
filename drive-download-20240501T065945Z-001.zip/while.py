print("Demonstation of while loop")

no = 5
i = 0

while(i <= no):
    print(i)
    i = i + 1

