import EvenOdd

def main():
    print("Enter number : ")
    A = int(input())

    EvenOdd.CheckEven(A)

# Starter
if __name__ == "__main__":
    main()