print("First Program of Python...")

# To compile the python Code
# python Demo.py

# To create .pyc file
# python -m compileall Demo.py
# It creates .pyc file in __pycache__ folder
# To execute the file
# python Demo.cpython-310.pyc
