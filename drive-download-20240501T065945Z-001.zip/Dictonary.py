print("Demonstration of Dictonary")

Price = {"Python" : 2000, "Java" : 1500, "C" : 1100, "C++" : 1100, "Java" : 4300}

print(Price)

print(type(Price))

print(Price["C"])

print(Price.keys())

print(Price.values())