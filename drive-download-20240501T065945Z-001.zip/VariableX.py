X = 11
print(type(X))

X = 67.90
print(type(X))

X = 'Python'
print(type(X))

X = False
print(type(X))

X = 89j
print(type(X))

A = B = C = 11
print(A)
print(B)
print(C)

P, Q, R = 10,20,30
print(P)
print(Q)
print(R)