print("Demonstration of Selection")

Age = 0

print("Enter your Age : ")
Age = int(input())

if(Age < 18):
    print("Sorry, You are not eligible for voting")
else:
    print("You can vote")

print("Thank you for using the application")