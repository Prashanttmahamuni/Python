# Set datatype

# Heterogeneous
# Unordered
# Unindexed
# Mutable
# Duplicate not allowed

Arr = {11, 78.90, True, "Marvellous",11}

print(Arr)
print(len(Arr))

# print(Arr[0])

Arr.add("Python")

print(Arr)

Arr.remove("Python")

print(Arr)