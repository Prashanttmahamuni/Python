# int No = 11;
No = 11

#printf("Value of No is %d\n",No);
print("Value of No is ",No)

print(type(No))

X = "Marvellous"
print(X)
print(type(X))

Marks = 90.67
print(Marks)
print(type(Marks))

Y = 6j
print(Y)
print(type(Y))

A = True
print(A)
print(type(A))