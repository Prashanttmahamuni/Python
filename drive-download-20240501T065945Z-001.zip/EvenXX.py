No = 12

if(No % 2 == 0):
    print("it is even")
else:
    print("It is odd")