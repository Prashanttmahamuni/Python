
# Defination of Function
def Fun():
    print("Inside Fun")
    print("Inside Python")


# Function Call
Fun()

def Gun():
    pass

Gun()
