print("Demonstration of for loop")

for no in range(5):
    print(no)

print("")

for no in range(2,8):
    print(no)

print("")

for no in range(2,14,2):
    print(no)    