
Cnt = int(input("Please enter frequency"))

i = 0

for i in range(Cnt):
    print("Jay Ganesh...")
