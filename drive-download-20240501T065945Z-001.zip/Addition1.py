# Typecasting

print("Enter first number : ")
No1 = int(input())

print("Enter second number : ")
No2 = int(input())

Ans = No1 + No2

print("Addition is : ",Ans)
