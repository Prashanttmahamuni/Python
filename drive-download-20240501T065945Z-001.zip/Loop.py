
Cnt = int(input("Please enter frequency"))

i = 0

while(i < Cnt):
    print("Jay Ganesh...")
    i = i + 1