# List datatype

# Heterogeneous
# Ordered
# Indexed
# Mutable
# Allows Duplicate

Arr = [11, 78.90, True, "Marvellous",11]

print("Length of list is : ",len(Arr))

print(Arr[3])

print(Arr[0])
Arr[0] = 21
print(Arr[0])

Arr.append(51)
print("Length of list is : ",len(Arr))
